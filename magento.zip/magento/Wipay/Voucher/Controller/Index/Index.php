<?php
namespace Wipay\Voucher\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_storeManager;
	protected $_scopeConfig;
	protected $_encryptor;
	protected $checkoutSession;
	protected $orderRepository;

	public function __construct(
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Framework\Encryption\EncryptorInterface $encryptor,
		\Magento\Checkout\Model\Session $checkoutSession,
		\Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->_scopeConfig = $scopeConfig;
		$this->_storeManager = $storeManager;
		$this->_encryptor = $encryptor;
		$this->checkoutSession = $checkoutSession;
		$this->orderRepository = $orderRepository;
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}

	public function execute()
	{
		//**Get the parameters
		$scope = $this->_storeManager->getStore()->getCode();
		$storeId = $this->_storeManager->getStore()->getId();
		if($scope == 'default'){
			$enacc = $this->_scopeConfig->getValue("payment/voucher/developer_id", 'default');
			$debug = $this->_scopeConfig->getValue("payment/voucher/debug", 'default');
		}else{
			$enacc = $this->_scopeConfig->getValue("payment/voucher/developer_id", 'stores', $storeId);
			$debug = $this->_scopeConfig->getValue("payment/voucher/debug", 'stores', $storeId);
		};
		$acc = $this->_encryptor->decrypt($enacc);
		$ttrate = $this->_storeManager->getStore()->getBaseCurrency()->getRate('TTD');
		$gateway = '';
		if($debug==0){
			$gateway = 'https://wipayfinancial.com/v1/voucher_pay';
		}else{
			$gateway = 'https://sandbox.wipayfinancial.com/v1/voucher_pay';
		}
		
		//**Get order from session. In xampp, session files are found at 'C:\xampp\tmp'. Order info is retrieved from 'sales_order' table from DB.
		$orderId = $this->checkoutSession->getLastOrderId();		
		$order = $this->orderRepository->get($orderId);
		//echo $orderId.'</br>';
			
		//**Set post data
		$post = [
			'account_number' => $acc,
			'details' => "This is a voucher payment from a magento store.",
			'total' => $order->getBaseGrandTotal() * $ttrate,
			'voucher' => $this->getRequest()->getParam('voucher'),
		];
				
		//**Get reponse from gateway
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $gateway);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($ch);				
		curl_close ($ch); 
		//echo $result;
		
		//**Redirect based on payment status
		$obj = json_decode($result);
		//echo $obj->status;
		
		$orderId = $this->checkoutSession->getLastOrderId();
		$order = $this->orderRepository->get($orderId);
		
		if($obj->status=='success'){
			//**Set order status to 'processing'
			$order->setData('state', "processing");
			$order->setStatus("processing"); 
			$order->setTotalPaid($order->getBaseGrandTotal());        
			$history = $order->addStatusHistoryComment($obj->msg.'. Transaction id: '.$obj->trxn_id, false);
			$history->setIsCustomerNotified(null); 
			$order->save(); 
			
			//**Goto to success page
			$this->messageManager->addSuccess(__('Payment has been successful.'));            
			$resultRedirect = $this->resultRedirectFactory->create();
			$resultRedirect->setPath('checkout/onepage/success');
			return $resultRedirect;
		}elseif($obj->status=='error'){
			//**Set order statis to 'canceled'		
			$order->setData('state', "canceled");
			$order->setStatus("canceled");       
			$history = $order->addStatusHistoryComment($obj->status.': '.$obj->msg, false);
			$history->setIsCustomerNotified(null);
			$order->save();
			
			//**Return to cart
			$this->messageManager->addError(__('Payment has been canceled.'));            
			$resultRedirect = $this->resultRedirectFactory->create();
			$resultRedirect->setPath('checkout/cart');
			return $resultRedirect;
		}else{
			//**Return to cart without saving transaction
			$this->messageManager->addError(__('No response from gateway. Please contact your merchant.'));            
			$resultRedirect = $this->resultRedirectFactory->create();
			$resultRedirect->setPath('checkout/cart');
			return $resultRedirect;
		}
			
		//return $this->_pageFactory->create();
	}
}