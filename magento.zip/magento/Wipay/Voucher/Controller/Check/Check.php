<?php
namespace Wipay\Voucher\Controller\Check;

class Check extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_scopeConfig;
	protected $checkoutSession;
	protected $orderRepository;

	public function __construct(
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Checkout\Model\Session $checkoutSession,
		\Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->_scopeConfig = $scopeConfig;
		$this->_storeManager = $storeManager;
		$this->checkoutSession = $checkoutSession;
		$this->orderRepository = $orderRepository;
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}

	public function execute()
	{
		//**Get the voucher code parameter
		$post = [
			'voucher' => $this->getRequest()->getParam('voucher'),
		];
		
		//**Set the gateway url based on admin config
		$scope = $this->_storeManager->getStore()->getCode();
		$storeId = $this->_storeManager->getStore()->getId();;
		if($scope == 'default'){
			$debug = $this->_scopeConfig->getValue("payment/voucher/debug", 'default');
		}else{
			$debug = $this->_scopeConfig->getValue("payment/voucher/debug", 'stores', $storeId);
		};
		$gateway = '';
		if($debug==0){
			$gateway = 'https://wipayfinancial.com/v1/voucher_check';
		}else{
			$gateway = 'https://sandbox.wipayfinancial.com/v1/voucher_check';
		}
				
		//**Get reponse from gateway
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $gateway);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($ch);				
		curl_close ($ch); 

		//**Show response for ajax call
		echo $result;

		//$obj = json_decode($result);
		//echo $obj->status;
				
		//return $this->_pageFactory->create();
	}
}