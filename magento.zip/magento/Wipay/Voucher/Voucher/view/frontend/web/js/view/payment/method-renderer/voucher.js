define(
    [
        'ko',
        'jquery',
        'Magento_Checkout/js/view/payment/default',
	'mage/url',
	'Magento_Ui/js/modal/alert'
    ],
    function (ko, $, Component, setPaymentMethodAction, url, alert) {
        'use strict';
        return Component.extend({
            defaults: {
                redirectAfterPlaceOrder: false,
                template: 'Wipay_Voucher/payment/voucher'
            },
			verifyCode: function () {
				$("#wipay_message").html('');
				event.preventDefault();
				var vcode = $('#vouchercode').val();
				var baseurl = require.toUrl('').substring(0, require.toUrl('').indexOf('pub'));
				var linkUrl = baseurl + 'voucherrouter/check/check?voucher=' + vcode;
				//var linkUrl = url.build('voucherrouter/check/check?voucher='+vcode);
				if(vcode !== ''){
					if(vcode.length==12){
						$.ajax({
							type: 'POST',
							url: linkUrl,
							success: function(msg){
								console.log(msg);
								var obj = JSON.parse(msg); 
								console.log(obj["status"]);
								if(obj["status"]=="success"){
									$("#wipay_message").html(obj["msg"]+'. Voucher value: $'+obj["value"]);
								}else if(obj["status"]=="error"){
									$("#wipay_message").html('Error: '+obj["msg"]);
								}else{
									$("#wipay_message").html('No response from gateway.');
								}
							},
							error: function (xhr, status, errorThrown) {
								$("#wipay_message").html('Cannot reach gateway.');
							}
						});						
					}else{
						$("#wipay_message").html('Invalid voucher code format.');
					}
					
				} 
			},
            afterPlaceOrder: function () {
				var baseurl = require.toUrl('').substring(0, require.toUrl('').indexOf('pub'));
				var orderurl = baseurl + 'voucherrouter/index/index?voucher=' + $('#vouchercode').val();
				//var orderurl = url.build('voucherrouter/index/index?voucher='+$('#vouchercode').val());
                window.location.href = orderurl;
                return false;
            }
        });
    }
);