define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'voucher',
                component: 'Wipay_Voucher/js/view/payment/method-renderer/voucher'
            }
        );
        return Component.extend({});
    }
);