=== Checkout Payment Gateway for Magento 2.3.X ===
Version: 1.1
Contributors: Vikash Kumar
Tags: payment gateway, magento payment gateway
Requires at least: 2.3.0
Tested up to: 2.3.3
Stable tag: 2.3.3
License: OSL-3.0
License URI: https://opensource.org/licenses/OSL-3.0

It's a Magento 2 extension allow clients make payments.

== Description ==
This extension allows customers to make purchases using WiPay�s payment gateway using credit cards and/or vouchers:
* Credit card: When an order is placed, the user is redirected to Wipay�s secure hosted payment page where only the credit card information is entered.
* Voucher: The customer can check the voucher then place an order using a Wipay voucher code.


== Installation ==
*These steps are for customers that already possess a Magento website on a server*

Step 1:  Download and extract on your Magento website server.
	* Go to the Developer Support section on the Wipay site.	
	* Go to the WiPay Plugin Guide and Click on the desired plugin link.
	* Upon downloding you will see the folder, Magento.zip, downloaded.
	* Upload the zip file using your FTP software to the �{magento root directory}/app/code� directory and extract in this directory.
Step 2:  Open the terminal console, navigate to the Magento root directory and run the following commands:
	* php bin/magento setup:di:compile
	* php bin/magento setup:upgrade
	* php bin/magento setup:static-content:deploy -f
	* php bin/magento indexer:reindex
	* php bin/magento cache:flush
Step 3:  Enable the modules on the checkout page from the admin panel:
	* On the Admin Panel, go Stores > Settings > Configuration > Sales > Payment Methods.
	* Enter information as needed for �Wipay Credit� and �Wipay Voucher� payment methods. See the FAQ section for test payment and test order setup.
Step 4:  If the base currency of your store is not TTD, setup your store to show TTD currency:
	* Go to Stores > Settings > Configuration
	* On the left panel, under General, select Currency Setup.
	* Under the Currency Options section, look for the Allow Currencies list and select �Trinidad and Tobago Dollar� for your store to display prices in TTD.
	* Hold down the Ctrl key to select multiple options.
	* On the admin panel, go to Stores > Currency > Currency Rates.
	* Enter the rates for TTD � USD currency in the currency column, then click save Currency rates.

Note: The merchant is responsible for changing the value of the exchange rate which is used to calculate the total to be paid in TTD. If the base store currency is
TTD, this value is 1 by default. 


== Frequently Asked Questions ==
= Question: When running the commands during installation, why do I get a memory limit error? =

Solution: To get pass a memory limit error, run the commands with:  
	php -d memory_limit=-1 bin/magento setup:di:compile
	php -d memory_limit=-1 bin/magento setup:upgrade
	php -d memory_limit=-1 bin/magento setup:static-content:deploy -f
	php -d memory_limit=-1 bin/magento indexer:reindex
	php -d memory_limit=-1 bin/magento cache:flush

= Question: After installation, the payment methods do not show up on the admin panel? =

Solution: You may have to enable the module. After installation, the status of the wipay credit card and voucher modules can be checked using the following commands:
	php bin/magento module:status Wipay_Credit
	php bin/magento module:status Wipay_Voucher
The modules can be disabled using the following commands:
	php bin/magento module:disable Wipay_Credit
	php bin/magento module:disable Wipay_Voucher
The modules can be enabled using the following commands:
	php bin/magento module:enable Wipay_Credit
	php bin/magento module:enable Wipay_Voucher
If the above commands did not work try clearing the cache. On the Magento admin panel, go to System > Tools > Cache Management and click the �Flush Magento Cache�
button. 

= Question: How to setup and perform a test payment and test order on Wipay Credit plugin? = 

Solution: Test values can be found on this link: https://wipaytoday.com/credit-card-documentation/
On the admin panel, configure the module settings as follows:
	Enable: Yes
	Developer ID: 1
	Merchant Key: 123
	Debug: Yes
	Absorb Transaction Fee: Yes
	Sort Order: 1
	Payment from Applicable Countries: All Allowed Countries
	Minimum Order Total: 10
	Maximum Order Total:
On the Wipay credit card payment page, enter the test information as follows: (use any card number information below, any CVV and date in the future of your choosing
to see different results)
Verify your purchase on the Sales > Orders page on the admin panel.
Note: To accept live payments, update the Developer ID, Merchant Key with your own WiPay developer ID and Merchant key; also adjust Test Mode (Debug) fields by 
changing Yes to No.

= Question: How do you setup and perform a test payment and test order on Wipay Voucher? =

Solution: On the admin panel, configure the module settings as follows:
	Enable: Yes
	Developer ID: 4630
	Debug: Yes
	Absorb Transaction Fee: Yes
	Sort Order: 2
	Payment from Applicable Countries: All Allowed Countries
	Minimum Order Total: 0.01
	Maximum Order Total:
On the checkout page, enter the information as follows:
Enter one (1) Voucher test Code: 
	uyr8vmap230t
	jxaqe48tfvbs
	zmq8x0y29usv
	xq62mu0s81jv
	b4zytr8e37si
	6v75kwyg3t0i
Verify your purchase on the Sales > Orders page on the admin panel.
Note: To accept live payments, update the Developer ID and Debug fields accordingly.

= Question: How to change order state and/or status? =

Solution:
A successful payment results in a �Processing� order state and �Processing� order status. An unsuccessful payment results in a �Canceled� order state and �Canceled�
order status.
To view orders and their states go to Sales > Orders on the admin panel. On this page you can click Action > View to see the details of any order.
When viewing the details of any order you can change the state by click any one of the following buttons:
	Edit: the current order will be canceled and duplicated into a new one
	Cancel: delete order
	Send email: send an email with order details to customers
	Hold: change order state to On Hold
	Invoice: change order state to Processing
	Ship: change order state to Complete (after submitting shipment)
	Reorder: resubmit the same order
Note: These options change the order state and each state can be assigned by multiple statuses (you may add custom order statuses). For example, for Pending state,
you can create two statuses: SM Pending and SH Pending, so you can change the status for this order into either SM Pending or SH Pending under �Notes� for any Order.
(Note that the state of this order is still Pending).

= Question: How do I perform cache management on my website? =

Solution: Go to System > Tools > Cache Management. Ensure the status of each cache type is enabled, if not select it by clicking the checkbox. Select the refresh 
option and hit submit.

= Question: How do I setup the plugins for mutliple stores? = 

Solution:
On the Admin Panel, go Stores > Settings > Configuration > Sales > Payment Methods.
Under the "Configuration" heading, select the store view and apply settings to that store view (only) by unchecking the "Use website" checkbox.


== Changelog ==
= 1.0 =
* It's first release
= 1.1 =
* Added multi-store functionality
* The "Total Paid" value in the admin order view page now gets updated.
* General bug fixes and improvements. 