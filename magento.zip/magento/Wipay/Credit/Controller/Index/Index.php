<?php
namespace Wipay\Credit\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{
	protected $_storeManager;
	protected $_scopeConfig;
	protected $_encryptor;
	protected $_checkoutSession;
	protected $orderRepository;
	protected $_pageFactory;
	
	public function __construct(
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Magento\Framework\Encryption\EncryptorInterface $encryptor,
		\Magento\Checkout\Model\Session $checkoutSession,
		\Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\App\Action\Context $context	
	){
		$this->_storeManager = $storeManager;
		$this->_scopeConfig = $scopeConfig;
		$this->_encryptor = $encryptor;
		$this->_checkoutSession = $checkoutSession;
		$this->orderRepository = $orderRepository;		
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}

	public function execute()  
	{	
		//**Get admin configuration parameters. See 'core_config_data' table in the database.
		$scope = $this->_storeManager->getStore()->getCode();
		$storeId = $this->_storeManager->getStore()->getId();
		if($scope == 'default'){
			$enkey = $this->_scopeConfig->getValue("payment/credit/developer_id", 'default');
			$debug = $this->_scopeConfig->getValue("payment/credit/debug", 'default');
			$absorbFee = $this->_scopeConfig->getValue("payment/credit/absorb_transaction_fee", 'default');
		}else{
			$enkey = $this->_scopeConfig->getValue("payment/credit/developer_id", 'stores', $storeId);
			$debug = $this->_scopeConfig->getValue("payment/credit/debug", 'stores', $storeId);
			$absorbFee = $this->_scopeConfig->getValue("payment/credit/absorb_transaction_fee", 'stores', $storeId);
		};
		$base_url = $this->_storeManager->getStore()->getBaseUrl();
		$key = $this->_encryptor->decrypt($enkey);
		$ttrate = $this->_storeManager->getStore()->getBaseCurrency()->getRate('TTD');
		if($debug==0){
			$gateway = 'https://wipayfinancial.com/v1/gateway_live';
		}else{
			$gateway = 'https://wipayfinancial.com/v1/gateway'; 
		}

		//**Get order from session. In xampp, session files are found at 'C:\xampp\tmp'. Order info is retrieved from 'sales_order' table from DB.
		$orderId = $this->_checkoutSession->getLastOrderId();
		$order = $this->orderRepository->get($orderId);
		$billingAddress = $order->getBillingAddress();

		//**Calculate the total using the admin defined TT exchange rate. The transaction fee is applied based on admin configuration.		
		if(!$absorbFee){
			$grand_total = $order->getBaseGrandTotal() * $ttrate;
		}else{
			$grand_total = $order->getBaseGrandTotal() * $ttrate * 1.03 + 2;
		}
		
		//**Set gateway post data	
		$post = [
			'total' => $grand_total,
			'phone' => $billingAddress->getTelephone(),
			'email' => $billingAddress->getEmail(),
			'name' =>  $billingAddress->getFirstname()." ".$billingAddress->getLastname(),
			'order_id' => $orderId,
			'return_url' => $base_url.'wipayroute/magereturn/magereturn',
			'developer_id' => $key,
		];

		//foreach($post as $result) {
		//	echo $result, '<br>';
		//}

		//**Redirect to gateway
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $gateway);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
		$result = curl_exec($ch);
		curl_close ($ch); 
	
		//return $this->_pageFactory->create();
	}
}