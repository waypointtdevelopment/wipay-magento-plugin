<?php
namespace Wipay\Credit\Controller\MageReturn;

class MageReturn extends \Magento\Framework\App\Action\Action
{
	protected $_scopeConfig;
	protected $_encryptor;
	protected $checkoutSession;
	protected $orderRepository;
	protected $_pageFactory;

	public function __construct(
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Magento\Framework\Encryption\EncryptorInterface $encryptor,
		\Magento\Checkout\Model\Session $checkoutSession,
		\Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\App\Action\Context $context
	){
		$this->_storeManager = $storeManager;
		$this->_scopeConfig = $scopeConfig;
		$this->_encryptor = $encryptor;
		$this->checkoutSession = $checkoutSession;
		$this->orderRepository = $orderRepository;
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}

	public function execute() 
	{
		//**Get url parameters
		$urlParams = $this->getRequest()->getParams();
		
		//**Validate payment using the harsh
		$scope = $this->_storeManager->getStore()->getCode();
		$storeId = $this->_storeManager->getStore()->getId();
		if($scope == 'default'){
			$enkey = $this->_scopeConfig->getValue("payment/credit/merchant_key", 'default');
		}else{
			$enkey = $this->_scopeConfig->getValue("payment/credit/merchant_key", 'stores', $storeId);
		};
		$merchant_key= $this->_encryptor->decrypt($enkey);
		$hash=md5($urlParams['order_id'].$urlParams['total'].$merchant_key);
		//echo $hash;
		
		//**Redirect based on status and validation. See 'sales_order' table for order status info and 'sales_order_status_history' table for payment info.
		$orderId = $this->checkoutSession->getLastOrderId();
		$order = $this->orderRepository->get($orderId);
		//echo $orderId;
		//$billingAddress = $order->getBillingAddress();
		//echo $billingAddress->getEmail(); 
 		
		if($urlParams['status'] == 'success') 
		{			
			if($hash == $urlParams['hash']) 
			{ 
				//**Set order status to 'processing'
				$order->setData('state', "processing");
				$order->setStatus("processing");
				$order->setTotalPaid($order->getBaseGrandTotal());       
				$history = $order->addStatusHistoryComment(rtrim($urlParams['reasonDescription'],'.').' at '.$urlParams['date'].'. Wipay transaction id: '.$urlParams['transaction_id'], false);
				$history->setIsCustomerNotified(null);
				$order->save();
					
				//**Goto to success page
				$this->messageManager->addSuccess(__('Payment has been successful.'));            
				$resultRedirect = $this->resultRedirectFactory->create();
				$resultRedirect->setPath('checkout/onepage/success');
				return $resultRedirect;
			}else{
				//**Set order status to 'canceled'		
				$order->setData('state', "canceled");
				$order->setStatus("cancel");       
				$history = $order->addStatusHistoryComment(rtrim($urlParams['reasonDescription'],'.').' at '.$urlParams['date'].'. Wipay transaction id: '.$urlParams['transaction_id'], false);
				$history->setIsCustomerNotified(null);
				$order->save();
				
				//**Return to cart
				$this->messageManager->addError(__('Payment has been cancelled. Validation failed.'));            
				$resultRedirect = $this->resultRedirectFactory->create();
				$resultRedirect->setPath('checkout/cart');
				return $resultRedirect;
			}
		}elseif($urlParams['status'] == 'failed'){
			//**Set order status to 'canceled'		
			$order->setData('state', "canceled");
			$order->setStatus("canceled");       
			$history = $order->addStatusHistoryComment(rtrim($urlParams['reasonDescription'],'.').' at '.$urlParams['date'].'. Wipay transaction id: '.$urlParams['transaction_id'], false);
			$history->setIsCustomerNotified(null);
			$order->save();
			
			//**Return to cart
			$this->messageManager->addError(__('Payment has been cancelled.'));            
			$resultRedirect = $this->resultRedirectFactory->create();
			$resultRedirect->setPath('checkout/cart');
			return $resultRedirect;
		}else{
			//**Return to cart without saving transaction data
			$this->messageManager->addError(__('No payment status response from gateway. Please contact your merchant.'));            
			$resultRedirect = $this->resultRedirectFactory->create();
			$resultRedirect->setPath('checkout/cart');
			return $resultRedirect;
		}

		//return $this->_pageFactory->create();
	}
}