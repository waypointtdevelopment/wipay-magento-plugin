define(
    [
        'ko',
        'jquery',
        'Magento_Checkout/js/view/payment/default',
		'mage/url'
    ],
    function (ko, $, Component, setPaymentMethodAction, url) {
        'use strict';
        return Component.extend({
            defaults: {
                redirectAfterPlaceOrder: false,
                template: 'Wipay_Credit/payment/credit'
            },
            afterPlaceOrder: function () {
				//window.location.href = url.build("wipayroute/index/index");
				var baseurl = require.toUrl('').substring(0, require.toUrl('').indexOf('pub'));
                window.location.href = baseurl + "wipayroute/index/index";
                return false;
            }
        });
    }
);